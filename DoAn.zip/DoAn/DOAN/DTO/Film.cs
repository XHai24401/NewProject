﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DOAN.DTO
{
    public class Film
    {
        public Film(string MP, string TP, string TL,string NC, string NKT,string MTP,string ML,string MQG,string TDN,string MSC,string MLSK)
        {

            this.MP = MP;
            this.TP = TP;
            this.TL = TL;
            this.NC = NC;
            this.NKT = NKT;
            this.MTP = MTP;
            this.ML = ML;
            this.MQG = MQG;
            this.TenDN = TDN;
            this.MSC = MSC;
            this.MLSK = MLSK;
        }

        public Film(DataRow row)
        {

            this.MP = row["MaPhim"].ToString();
            this.TP = row["TenPhim"].ToString();
            this.TL = row["Thoiluong"].ToString();
            this.NC = row["NgayChieu"].ToString();
            this.NKT = row["NgayKT"].ToString();
            this.MTP = row["MoTaPhim"].ToString();
            this.ML = row["MaLoai"].ToString();
            this.MQG = row["MaQuocGia"].ToString();
            this.TenDN = row["TenDangNhapNV"].ToString();
            this.MSC = row["MASC"].ToString();
            this.MLSK = row["Maloaisukien"].ToString();
            

        }






        private string MP;
        public string MaPhim
        {
            get { return MP; }
            set { MP = value; }
        }


        private string TP;
        public string TenPhim
        {
            get { return TP; }
            set { TP = value; }
        }

        private string TL;

        public string ThoiLuong
        {
            get { return TL; }
            set { TL = value; }
        }


        private string NC;

        public string NgayChieu
        {
            get { return NC; }
            set { NC = value; }
        }

        private string NKT;

        public string NgayKT
        {
            get { return NKT; }
            set { NKT = value; }
        }

        private string MTP;

        public string MoTaPhim
        {
            get { return MTP; }
            set { MTP = value; }
        }

        private string ML;

        public string MaLoai
        {
            get { return ML; }
            set { ML = value; }
        }

        private string MQG;

        public string MaQG
        {
            get { return MQG; }
            set { MQG = value; }
        }


        private string TenDN;

        public string TenDangNhapNV
        {
            get { return TenDN; }
            set { TenDN = value; }
        }



        private String MSC;
        public string MaSC
        {
            get { return MSC; }
            set { MSC = value; }
        }

        private string MLSK;

        public string MaLSK
        {
            get { return MLSK; }
            set { MLSK = value; }
        }

    }
}
