﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DOAN.DTO
{
    public class Food
    {
        public Food(string Ma, string Ten, string GIA, string TDN)
        {
           
            this.Ma = Ma;
            this.Ten = Ten;
            this.Gia = GIA;
            this.TenDN = TDN;

        }

        public Food(DataRow row)
        {
            
            this.Ma= row["MaThucAn"].ToString();
            this.Ten = row["TenThucAn"].ToString();
            this.Gia = row["Gia"].ToString();
            this.TenDN = row["TenDangNhapNV"].ToString();

        }


       



        private string Ma;
        public string MaTA
        {
            get { return Ma; }
            set { Ma = value; }
        }


        private string Ten;
        public string TenTA
        {
            get { return Ten; }
            set { Ten = value; }
        }

        



        private String Gia;
        public string GIA
        {
            get { return Gia; }
            set { Gia = value; }
        }

        private string TenDN;

        public string TenDangNhapNV
        {
            get { return TenDN; }
            set { TenDN = value; }
        }
    }
}
