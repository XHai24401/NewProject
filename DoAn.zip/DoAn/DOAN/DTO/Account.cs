﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DOAN.DTO
{
    public class Account
    {
        public Account(string TDN, string MK, string Ma, string Ten, string NgaySinh, string GT, string CV)
        {
            this.TenDN = TDN;
            this.mk = MK;
            this.MaNV = Ma;
            this.Ten = Ten;
            this.NS = NgaySinh;
            this.GioiTinh = GT;
            this.ChucVu = CV;

        }

        public Account(DataRow row)
        {
            this.TenDN = row["TenDangNhapNV"].ToString();
            this.mk = row["matkhau"].ToString(); 
            this.MaNV = row["MaNV"].ToString();
            this.Ten = row["TenNv"].ToString(); 
            this.NS = row["NgaySinh"].ToString(); 
            this.GioiTinh = row["GioiTinh"].ToString(); 
            this.ChucVu = row["ChucVu"].ToString(); 

        }


        private string TenDN;

        public string TenDangNhapNV
        {
            get { return TenDN; }
            set { TenDN = value; }
        }


        private string mk;
        public string MatKhau
        {
            get { return mk; }
            set { mk = value; }
        }
        private string MaNv;
        public string MaNV
        {
            get { return MaNv; }
            set { MaNv = value; }
        }


        private string Ten;
        public string TenNV
        {
            get { return Ten; }
            set { Ten = value; }
        }

        private string NS;
        public string NgaySinh
        {
            get { return NS; }
            set { NS = value; }
        }

       

        private String GT;
        public string GioiTinh
        {
            get { return GT; }
            set { GT = value; }
        }

        private string CV;
        public string ChucVu
        {
            get { return CV; }
            set { CV = value; }
        }






    }
}
        

     

 