﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DOAN.DTO
{
    public class Eventt
    {
        public Eventt(string MaSK, string NDR)
        {

            this.MaSK = MaSK;
            this.NDR = NDR;
          

        }

        public Eventt(DataRow row)
        {

            this.MaSK = row["Maloaisukien"].ToString();
            this.NDR = row["Ngaydienra"].ToString();
            

        }


        private string MaSK;
        public string MaLoaiSK
        {
            get { return MaSK; }
            set { MaSK = value; }
        }


        private string NDR;
        public string NgayDienRa
        {
            get { return NDR; }
            set { NDR = value; }
        }





        
    }
}
