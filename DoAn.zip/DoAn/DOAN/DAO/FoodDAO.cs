﻿using DOAN.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DOAN.DAO
{
    public class FoodDAO
    {
        private static FoodDAO instance;



        public static FoodDAO Instance
        {
            get { if (instance == null) instance = new FoodDAO(); return FoodDAO.instance; }
            private set { FoodDAO.instance = value; }
        }

        private FoodDAO() { }


        public List<Food> GetFood()
        {
            List<Food> list = new List<Food>();

            string query = "select * from THUCAN";
            DataTable dataTable = DataProvider.Instance.ExecuteQuery(query);

            foreach (DataRow item in dataTable.Rows)
            {
                Food food = new Food(item);
                list.Add(food);
            }

            return list;
        }

        public List<Food> SearchFood(string id)
        {
            List<Food> list = new List<Food>();

            string query = string.Format("select * from ThucAn where [dbo].[GetUnsignString](TenThucAn) like N'%' +[dbo].[GetUnsignString](N'{0}') + '%'", id);
            DataTable dataTable = DataProvider.Instance.ExecuteQuery(query);

            foreach (DataRow item in dataTable.Rows)
            {
                Food food = new Food(item);
                list.Add(food);
            }

            return list;
        }

        public bool InsertFood(string Ma, string Ten, string GIA, string TDN)
        {
            string query = string.Format("insert ThucAn (MaThucAn,TenThucAn,Gia,TenDangNhapNV)values('{0}',N'{1}','{2}','{3}')", Ma, Ten, GIA, TDN);
            int result = DataProvider.Instance.ExecuteNonQuery(query);

            return result > 0;
        }
        public bool UpdateFood(string Ma, string Ten, string GIA, string TDN)
        {
            string query = string.Format("update ThucAn set TenThucAn=N'{1}', Gia='{2}',TenDangNhapNV='{3}' where MaThucAn='{0}'", Ma, Ten, GIA,TDN);
            int result = DataProvider.Instance.ExecuteNonQuery(query);

            return result > 0;
        }

        public bool DeleteFood(string TenDN)
        {
            string query = string.Format("delete ThucAn  where TenDangNhapNV='{0}'", TenDN);
            int result = DataProvider.Instance.ExecuteNonQuery(query);

            return result > 0;
        }
    }
}
