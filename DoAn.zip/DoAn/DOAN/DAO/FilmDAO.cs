﻿using DOAN.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DOAN.DAO
{
    public class FilmDAO
    {
        private static FilmDAO instance;



        public static FilmDAO Instance
        {
            get { if (instance == null) instance = new FilmDAO(); return FilmDAO.instance; }
            private set { FilmDAO.instance = value; }
        }

        private FilmDAO() { }


        public List<Film> GetFilm()
        {
            List<Film> list = new List<Film>();

            string query = "select * from PHIM";
            DataTable dataTable = DataProvider.Instance.ExecuteQuery(query);

            foreach (DataRow item in dataTable.Rows)
            {
                Film film = new Film(item);
                list.Add(film);
            }

            return list;
        }


        public List<Film> SearchFilm(string id)
        {
            List<Film> list = new List<Film>();

            string query = string.Format("select * from Phim where [dbo].[GetUnsignString](TenPhim) like N'%' +[dbo].[GetUnsignString](N'{0}') + '%'", id);
            DataTable dataTable = DataProvider.Instance.ExecuteQuery(query);

            foreach (DataRow item in dataTable.Rows)
            {
                Film film = new Film(item);
                list.Add(film);
            }

            return list;
        }

        public bool InsertFilm(string MP, string TP, string TL, string NC, string NKT, string MTP, string ML, string MQG, string TDN, string MSC, string MLSK)
        {
            string query = string.Format("insert Phim (MaPhim,TenPhim,Thoiluong,NgayChieu,NgayKT,MoTaPhim,MaLoai,MaQuocGia,TenDangNhapNV,MASC,Maloaisukien)values('{0}',N'{1}','{2}','{3}','{4}',N'{5}','{6}','{7}','{8}','{9}','{10}')",  MP,  TP, TL, NC,  NKT,  MTP,ML,  MQG,  TDN, MSC,MLSK);
            int result = DataProvider.Instance.ExecuteNonQuery(query);

            return result > 0;
        }
        public bool UpdateFilm(string MP, string TP, string TL, string NC, string NKT, string MTP, string ML,string MQG, string TDN, string MSC, string MLSK)
        {
            string query = string.Format("update Phim set TenPhim=N'{1}',Thoiluong='{2}',NgayChieu='{3}',NgayKT='{4}',MoTaPhim=N'{5}',MaLoai='{6}',MaQuocGia='{7}',TenDangNhapNV='{8}',MASC='{9}',Maloaisukien='{10}' where  MaPhim='{0}'",  MP,TP, TL, NC, NKT, MTP,ML, MQG, TDN, MSC, MLSK);
            int result = DataProvider.Instance.ExecuteNonQuery(query);

            return result > 0;
        }

        public bool DeleteFilm(string TenDN)
        {
            string query = string.Format("delete Phim  where TenDangNhapNV='{0}'", TenDN);
            int result = DataProvider.Instance.ExecuteNonQuery(query);

            return result > 0;
        }
    }
}
