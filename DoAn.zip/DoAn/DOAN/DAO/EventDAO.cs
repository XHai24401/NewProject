﻿using DOAN.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DOAN.DAO
{
    public class EventDAO
    {
        private static EventDAO instance;



        public static EventDAO Instance
        {
            get { if (instance == null) instance = new EventDAO(); return EventDAO.instance; }
            private set { EventDAO.instance = value; }
        }

        private EventDAO() { }


        public List<Eventt> GetEventt()
        {
            List<Eventt> list = new List<Eventt>();

            string query = "select * from SuKien";
            DataTable dataTable = DataProvider.Instance.ExecuteQuery(query);

            foreach (DataRow item in dataTable.Rows)
            {
                Eventt eventt = new Eventt(item);
                list.Add(eventt);
            }

            return list;
        }


        public bool InsertEventt(string MaSK, string NDR)
        {
            string query = string.Format("insert SuKien (Maloaisukien,Ngaydienra)values('{0}','{1}')", MaSK, NDR);
            int result = DataProvider.Instance.ExecuteNonQuery(query);

            return result > 0;
        }
        public bool UpdateEventt(string MaSK, string NDR)
        {
            string query = string.Format("update SuKien set Ngaydienra='{1}' where  Maloaisukien='{0}'",MaSK,NDR);
            int result = DataProvider.Instance.ExecuteNonQuery(query);

            return result > 0;
        }

        public bool DeleteEventt(string MaSK)
        {
            string query = string.Format("delete Sukien  where Maloaisukien='{0}'", MaSK);
            int result = DataProvider.Instance.ExecuteNonQuery(query);

            return result > 0;
        }
    }
}
