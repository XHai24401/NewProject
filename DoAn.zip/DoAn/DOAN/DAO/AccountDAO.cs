﻿using DOAN.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DOAN.DAO
{
    public class AccountDAO
    {
        private static AccountDAO instance;



        public static AccountDAO Instance
        {
            get { if (instance == null) instance = new AccountDAO(); return AccountDAO.instance; }
            private set { AccountDAO.instance = value; }
        }

        private AccountDAO() { }

        public List<Account> GetAccountsByID(int id)
        {
            List < Account > list= new List<Account>();

            string query = "";
            DataTable dataTable = DataProvider.Instance.ExecuteQuery(query);

            foreach(DataRow item in dataTable.Rows)
            {
                Account account = new Account(item);
                list.Add(account);
            }

            return list;
        }

        public List<Account> GetAccounts()
        {
            List<Account> list = new List<Account>();

            string query = "select * from NhanVien";
            DataTable dataTable = DataProvider.Instance.ExecuteQuery(query);

            foreach (DataRow item in dataTable.Rows)
            {
                Account account = new Account(item);
                list.Add(account);
            }

            return list;
        }

        public List<Account> SearchAcc(string id)
        {
            List<Account> list = new List<Account>();

            string query =string.Format ("select * from NHANVIEN where [dbo].[GetUnsignString](TenNv) like N'%' +[dbo].[GetUnsignString](N'{0}') + '%'",id);
            DataTable dataTable = DataProvider.Instance.ExecuteQuery(query);

            foreach (DataRow item in dataTable.Rows)
            {
                Account account = new Account(item);
                list.Add(account);
            }

            return list;
        }

        public DataTable GetListAccount()
        {
            return DataProvider.Instance.ExecuteQuery("select TenDN, MK, Ma, Ten, dateTime, GT, CV from NhanVien");
        }

       

        public bool Login(string username,string pass)
        {
            string query = "select * from NHANVIEN where TenDangNhapNV ='"+username+"' and MatKhau='"+pass+"'";
            
            DataTable result = DataProvider.Instance.ExecuteQuery(query);
            
            return result.Rows.Count>0;
        }

        public bool InsertAccount(string TenDN, string MK, string Ma, string Ten, string NgaySinh, string GT, string CV)
        {
            string query =string.Format("insert NhanVien (TenDangNhapNV,matkhau,MaNV,TenNv,NgaySinh,GioiTinh,ChucVu)values('{0}','{1}','{2}',N'{3}','{4}',N'{5}',N'{6}')", TenDN, MK, Ma, Ten, NgaySinh, GT, CV);
            int result = DataProvider.Instance.ExecuteNonQuery(query);

            return result > 0;
        }
        public bool UpdateAccount(string TenDN, string MK, string Ma, string Ten, string NgaySinh, string GT, string CV)
        {
            string query = string.Format("update NhanVien set matKhau='{1}', MaNV='{2}',TenNv=N'{3}',NgaySinh='{4}',GioiTinh=N'{5}',ChucVu=N'{6}' where TenDangNhapNV='{0}'", TenDN, MK, Ma, Ten, NgaySinh, GT, CV);
            int result = DataProvider.Instance.ExecuteNonQuery(query);

            return result > 0;
        }

        public bool DeleteAccount(string TenDN)
        {
            string query = string.Format("delete NhanVien  where TenDangNhapNV='{0}'", TenDN);
            int result = DataProvider.Instance.ExecuteNonQuery(query);

            return result > 0;
        }
    }
    
}
