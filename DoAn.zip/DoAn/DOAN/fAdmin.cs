﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using System.Data.SqlClient;
using DOAN.DAO;
using DOAN.DTO;
using DOAN.Model;

namespace DOAN
{
    public partial class fAdmin : Form
    {
        BindingSource AccountList = new BindingSource();
        BindingSource Foodlist = new BindingSource();
        BindingSource Filmlist = new BindingSource();
        BindingSource Eventtlist = new BindingSource();

        public fAdmin()
        {
            InitializeComponent();
            load();
        }

        void load()
        {
            DGVTK.DataSource = AccountList;
            DGVTA.DataSource = Foodlist;
            DGVP.DataSource = Filmlist;
            DGVSK.DataSource = Eventtlist;
            loadTK();
            AddAcc();

            loadFood();
            AddFood();

            loadFilm();
            AddFilm();
            TypeContextDB context = new TypeContextDB();
            FillFalcultyCombobox(context.LOAIPHIMs.ToList());

            loadEventt();
            AddEventt();

            


        }


        #region void

        void loadTK()
        {
            AccountList.DataSource = AccountDAO.Instance.GetAccounts();
        }

        void loadFood()
        {
            Foodlist.DataSource = FoodDAO.Instance.GetFood();
        }

        void loadFilm()
        {
            Filmlist.DataSource = FilmDAO.Instance.GetFilm();

        }

        void loadEventt()
        {
            Eventtlist.DataSource = EventDAO.Instance.GetEventt();
        }

        void AddAcc()
        {
            txtenDN.DataBindings.Add(new Binding("text", DGVTK.DataSource, "TenDangNhapNV"));
            txmkNV.DataBindings.Add(new Binding("text", DGVTK.DataSource, "MatKhau"));
            txmaNV.DataBindings.Add(new Binding("text", DGVTK.DataSource, "MaNV"));
            txtenNV.DataBindings.Add(new Binding("text", DGVTK.DataSource, "TenNV"));
            txngayNV.DataBindings.Add(new Binding("text", DGVTK.DataSource, "NgaySinh"));
            txgtNV.DataBindings.Add(new Binding("text", DGVTK.DataSource, "GioiTinh"));
            txcvNV.DataBindings.Add(new Binding("text", DGVTK.DataSource, "ChucVu"));

        }
        void AddFood()
        {
            txmaTA.DataBindings.Add(new Binding("text", DGVTA.DataSource, "MaTA"));
            txtenTA.DataBindings.Add(new Binding("text", DGVTA.DataSource, "TenTA"));
            txgiaTA.DataBindings.Add(new Binding("text", DGVTA.DataSource, "GIA"));
            txtenDN2.DataBindings.Add(new Binding("text", DGVTA.DataSource, "TenDangNhapNV"));

        }

        void AddFilm()
        {
            txmaP.DataBindings.Add(new Binding("text", DGVP.DataSource, "MaPhim"));
            txtenP.DataBindings.Add(new Binding("text", DGVP.DataSource, "TenPhim"));
            txtlP.DataBindings.Add(new Binding("text", DGVP.DataSource, "ThoiLuong"));
            txncP.DataBindings.Add(new Binding("text", DGVP.DataSource, "NgayChieu"));
            txnktP.DataBindings.Add(new Binding("text", DGVP.DataSource, "NgayKT"));
            txmtP.DataBindings.Add(new Binding("text", DGVP.DataSource, "MoTaPhim"));
            cbmalP.DataBindings.Add(new Binding("text", DGVP.DataSource, "MaLoai"));
            txmaQG.DataBindings.Add(new Binding("text", DGVP.DataSource, "MaQG"));
            txtenDN3.DataBindings.Add(new Binding("text", DGVP.DataSource, "TenDangNhapNV"));
            txmascP.DataBindings.Add(new Binding("text", DGVP.DataSource, "MaSC"));
            txmaskP.DataBindings.Add(new Binding("text", DGVP.DataSource, "MaLSK"));

        }

        void AddEventt()
        {
            txmaSK.DataBindings.Add(new Binding("text", DGVSK.DataSource, "MaLoaiSK"));
            txNDR.DataBindings.Add(new Binding("text", DGVSK.DataSource, "NgayDienRa"));

        }




        private void frmStudentManagement_Load(object sender, EventArgs e)
        {
            try
            {
                TypeContextDB context = new TypeContextDB();
                List<LOAIPHIM> listLOAIPHIMs = context.LOAIPHIMs.ToList();
                List<Phim> listPhims = context.Phims.ToList();
                FillFalcultyCombobox(listLOAIPHIMs);
                BindGrid(listPhims);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void FillFalcultyCombobox(List<LOAIPHIM> listLOAIPHIMs)
        {
            this.cbmalP.DataSource = listLOAIPHIMs;
            this.cbmalP.DisplayMember = "MaLoai";
            this.cbmalP.ValueMember = "MaLoai";
        }

        private void BindGrid(List<Phim> listPhims)
        {
            DGVP.Rows.Clear();
            foreach (var item in listPhims)
            {
                int index = DGVP.Rows.Add();
                DGVP.Rows[index].Cells[0].Value = item.MaPhim;
                DGVP.Rows[index].Cells[1].Value = item.TenPhim;
                DGVP.Rows[index].Cells[2].Value = item.Thoiluong;
                DGVP.Rows[index].Cells[3].Value = item.NgayChieu;
                DGVP.Rows[index].Cells[4].Value = item.NgayKT;
                DGVP.Rows[index].Cells[5].Value = item.MoTaPhim;
                DGVP.Rows[index].Cells[6].Value = item.LOAIPHIM.MaLoai;
                DGVP.Rows[index].Cells[7].Value = item.MaQuocGia;
                DGVP.Rows[index].Cells[8].Value = item.TenDangNhapNV;
                DGVP.Rows[index].Cells[9].Value = item.MASC;
                DGVP.Rows[index].Cells[10].Value = item.Maloaisukien;
            }
        }


        #endregion void



        #region list
        List<Account> SearchAcc(string id)
        {
            List<Account> listAcc = AccountDAO.Instance.SearchAcc(id);

            return listAcc;
        }

        List<Food> SearchFood(string id)
        {
            List<Food> listFood = FoodDAO.Instance.SearchFood(id);

            return listFood;
        }

        List<Film> SearchFilm(string id)
        {
            List<Film> listFilm = FilmDAO.Instance.SearchFilm(id);

            return listFilm;
        }
        #endregion list



        #region Click tài khoản
        private void btloadTK_Click(object sender, EventArgs e)
        {

            loadTK();
        }

        private void btthemTK_Click(object sender, EventArgs e)
        {
            string TenDN = txtenDN.Text;
            string MK = txmkNV.Text;
            string Ma = txmaNV.Text;
            string Ten = txtenNV.Text;
            string NgaySinh = txngayNV.Text;
            string GT = txgtNV.Text;
            string CV = txcvNV.Text;


            if (AccountDAO.Instance.InsertAccount(TenDN, MK, Ma, Ten, NgaySinh, GT, CV))
            {
                MessageBox.Show("Thêm thành công", "Thông báo");
                loadTK();
            }
            else
            {
                MessageBox.Show("Thêm thất bại, vui lòng kiễm tra lại", "Thông báo");
            }
        }

        private void btsuaTK_Click_1(object sender, EventArgs e)
        {
            string TenDN = txtenDN.Text;
            string MK = txmkNV.Text;
            string Ma = txmaNV.Text;
            string Ten = txtenNV.Text;
            string NgaySinh = txngayNV.Text;
            string GT = txgtNV.Text;
            string CV = txcvNV.Text;


            if (AccountDAO.Instance.UpdateAccount(TenDN, MK, Ma, Ten, NgaySinh, GT, CV))
            {
                MessageBox.Show("Cập nhật thành công", "Thông báo");
                loadTK();
            }
            else
            {
                MessageBox.Show("Cập nhật thất bại, vui lòng kiễm tra lại", "Thông báo");
            }
        }

        private void btxoaTK_Click(object sender, EventArgs e)
        {
            string TenDN = txtenDN.Text;
            string MK = txmkNV.Text;
            string Ma = txmaNV.Text;
            string Ten = txtenNV.Text;
            string NgaySinh = txngayNV.Text;
            string GT = txgtNV.Text;
            string CV = txcvNV.Text;


            if (AccountDAO.Instance.DeleteAccount(TenDN))
            {
                MessageBox.Show("Xóa thành công", "Thông báo");
                loadTK();
            }
            else
            {
                MessageBox.Show("Xóa thất bại, vui lòng kiễm tra lại", "Thông báo");
            }
        }

        private void bttimTK_Click(object sender, EventArgs e)
        {
            AccountList.DataSource = SearchAcc(ttimTK.Text);
        }
        #endregion Click tài khoản



        #region Click Food
        private void btloadTA_Click(object sender, EventArgs e)
        {
            loadFood();
        }

        private void bthemTA_Click(object sender, EventArgs e)
        {

            string Ma = txmaTA.Text;
            string Ten = txtenTA.Text;
            string Gia = txgiaTA.Text;
            string TenDN = txtenDN2.Text;


            if (FoodDAO.Instance.InsertFood(Ma, Ten, Gia, TenDN))
            {
                MessageBox.Show("Thêm thành công", "Thông báo");
                loadFood();
            }
            else
            {
                MessageBox.Show("Thêm thất bại, vui lòng kiễm tra lại", "Thông báo");
            }
        }


        private void btsuaTA_Click(object sender, EventArgs e)
        {
            string Ma = txmaTA.Text;
            string Ten = txtenTA.Text;
            string Gia = txgiaTA.Text;
            string TenDN = txtenDN2.Text;


            if (FoodDAO.Instance.UpdateFood(Ma, Ten, Gia, TenDN))
            {
                MessageBox.Show("Cập nhật thành công", "Thông báo");
                loadFood();
            }
            else
            {
                MessageBox.Show("Cập nhật thất bại, vui lòng kiễm tra lại", "Thông báo");
            }
        }

        private void btxoaTA_Click(object sender, EventArgs e)
        {
            string Ma = txmaTA.Text;
            string Ten = txtenTA.Text;
            string Gia = txgiaTA.Text;
            string TenDN = txtenDN2.Text;


            if (FoodDAO.Instance.DeleteFood(TenDN))
            {
                MessageBox.Show("Xóa thành công", "Thông báo");
                loadFood();
            }
            else
            {
                MessageBox.Show("Xóa thất bại, vui lòng kiễm tra lại", "Thông báo");
            }
        }
        private void bttimTA_Click(object sender, EventArgs e)
        {
            Foodlist.DataSource = SearchFood(ttimTA.Text);
        }


        #endregion Click Food



        #region Click Phim
        private void btloadP_Click(object sender, EventArgs e)
        {
            loadFilm();
        }

        private void btthemP_Click(object sender, EventArgs e)
        {
            
                string MP = txmaP.Text;
                string TP = txtenP.Text;
                string TL = txtlP.Text;
                string NC = txncP.Text;
                string NKT = txnktP.Text;
                string MTP = txmtP.Text;
                string ML = cbmalP.Text;
                string MQG = txmaQG.Text;
                string TenDN = txtenDN3.Text;
                string MSC = txmascP.Text;
                string MLSK = txmaskP.Text;


                if (FilmDAO.Instance.InsertFilm(MP, TP, TL, NC, NKT, MTP,ML, MQG, TenDN, MSC, MLSK))
                {
                    MessageBox.Show("Thêm thành công", "Thông báo");
                    loadFilm();
                }
                else
                {
                    MessageBox.Show("Thêm thất bại, vui lòng kiễm tra lại", "Thông báo");
                }

           
        }

        private void btsuaP_Click(object sender, EventArgs e)
        {
            string MP = txmaP.Text;
            string TP = txtenP.Text;
            string TL = txtlP.Text;
            string NC = txncP.Text;
            string NKT = txnktP.Text;
            string MTP = txmtP.Text;
            string ML = cbmalP.Text;
            string MQG = txmaQG.Text;
            string TenDN = txtenDN3.Text;
            string MSC = txmascP.Text;
            string MLSK = txmaskP.Text;


            if (FilmDAO.Instance.UpdateFilm(MP, TP, TL, NC, NKT, MTP,ML, MQG, TenDN, MSC, MLSK))
            {
                MessageBox.Show("Cập nhật thành công", "Thông báo");
                loadFilm();
            }
            else
            {
                MessageBox.Show("Cập nhật thất bại, vui lòng kiễm tra lại", "Thông báo");
            }
        }

        private void btxoaP_Click(object sender, EventArgs e)
        {
            string MP = txmaP.Text;
            string TP = txtenP.Text;
            string TL = txtlP.Text;
            string NC = txncP.Text;
            string NKT = txnktP.Text;
            string MTP = txmtP.Text;
            string ML = cbmalP.Text;
            string MQG = txmaQG.Text;
            string TenDN = txtenDN3.Text;
            string MSC = txmascP.Text;
            string MLSK = txmaskP.Text;


            if (FilmDAO.Instance.DeleteFilm(TenDN))
            {
                MessageBox.Show("Xóa thành công", "Thông báo");
                loadFilm();
            }
            else
            {
                MessageBox.Show("Xóa thất bại, vui lòng kiễm tra lại", "Thông báo");
            }
        }

        private void bttimP_Click(object sender, EventArgs e)
        {
            Filmlist.DataSource = SearchFilm(ttimP.Text);
        }

        #endregion Click Phim



        #region Click Sự kiện
        private void btloadSK_Click(object sender, EventArgs e)
        {
            loadEventt();
        }

        private void btthemSK_Click(object sender, EventArgs e)
        {
            string MaSK = txmaSK.Text;
            string NDR = txNDR.Text;



            if (EventDAO.Instance.InsertEventt(MaSK, NDR))
            {
                MessageBox.Show("Thêm thành công", "Thông báo");
                loadEventt();
            }
            else
            {
                MessageBox.Show("Thêm thất bại, vui lòng kiễm tra lại", "Thông báo");
            }
        }

        private void btsuaSK_Click(object sender, EventArgs e)
        {
            string MaSK = txmaSK.Text;
            string NDR = txNDR.Text;



            if (EventDAO.Instance.UpdateEventt(MaSK, NDR))
            {
                MessageBox.Show("Cập nhật thành công", "Thông báo");
                loadEventt();
            }
            else
            {
                MessageBox.Show("Cập nhật thất bại, vui lòng kiễm tra lại", "Thông báo");
            }
        }

        private void btxoaSK_Click(object sender, EventArgs e)
        {
            string MaSK = txmaSK.Text;
            string NDR = txNDR.Text;



            if (EventDAO.Instance.DeleteEventt(MaSK))
            {
                MessageBox.Show("Xóa thành công", "Thông báo");
                loadEventt();
            }
            else
            {
                MessageBox.Show("Xóa thất bại, vui lòng kiễm tra lại", "Thông báo");
            }
        }

        #endregion Click Sự kiện


    }

}

