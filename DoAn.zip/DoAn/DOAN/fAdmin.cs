﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using System.Data.SqlClient;
using DOAN.DAO;
using DOAN.DTO;

namespace DOAN
{
    public partial class fAdmin : Form
    {
        BindingSource AccountList = new BindingSource();
        public fAdmin()
        {
            InitializeComponent();
            load();
        }

        void load()
        {
            DGVTK.DataSource = AccountList;
            loadTK();
            AddAcc();
        }


        void loadTK()
        {

            AccountList.DataSource = AccountDAO.Instance.GetAccounts();

           
        }

        void AddAcc()
        {
            txtenDN.DataBindings.Add(new Binding("text",DGVTK.DataSource, "TenDangNhapNV"));
            txmkNV.DataBindings.Add(new Binding("text", DGVTK.DataSource, "MatKhau"));
            txmaNV.DataBindings.Add(new Binding("text", DGVTK.DataSource, "MaNV"));
            txtenNV.DataBindings.Add(new Binding("text", DGVTK.DataSource, "TenNV"));
            txngayNV.DataBindings.Add(new Binding("text", DGVTK.DataSource, "NgaySinh"));
            txgtNV.DataBindings.Add(new Binding("text", DGVTK.DataSource, "GioiTinh"));
            txcvNV.DataBindings.Add(new Binding("text", DGVTK.DataSource, "ChucVu"));
            
        }

        List<Account> SearchAcc(string id)
        {
            List<Account> listAcc = AccountDAO.Instance.SearchAcc(id);

            return listAcc;
        }

        private void btloadTK_Click(object sender, EventArgs e)
        {
           
            loadTK();
        }

        private void btthemTK_Click(object sender, EventArgs e)
        {
            string TenDN = txtenDN.Text;
            string MK = txmkNV.Text;
            string Ma = txmaNV.Text;
            string Ten = txtenNV.Text;
            string NgaySinh = txngayNV.Text;
            string GT = txgtNV.Text;
            string CV = txcvNV.Text;
            

            if(AccountDAO.Instance.InsertAccount(TenDN, MK, Ma, Ten, NgaySinh, GT, CV))
            {
                MessageBox.Show("Thêm thành công","Thông báo");
                loadTK();
            }
            else
            {
                MessageBox.Show("Thêm thất bại, vui lòng kiễm tra lại", "Thông báo");
            }
        } 

        private void btsuaTK_Click_1(object sender, EventArgs e)
        {
            string TenDN = txtenDN.Text;
            string MK = txmkNV.Text;
            string Ma = txmaNV.Text;
            string Ten = txtenNV.Text;
            string NgaySinh = txngayNV.Text;
            string GT = txgtNV.Text;
            string CV = txcvNV.Text;


            if (AccountDAO.Instance.UpdateAccount(TenDN, MK, Ma, Ten, NgaySinh, GT, CV))
            {
                MessageBox.Show("Cập nhật thành công", "Thông báo");
                loadTK();
            }
            else
            {
                MessageBox.Show("Cập nhật thất bại, vui lòng kiễm tra lại", "Thông báo");
            }
        }

        private void btxoaTK_Click(object sender, EventArgs e)
        {
            string TenDN = txtenDN.Text;
            string MK = txmkNV.Text;
            string Ma = txmaNV.Text;
            string Ten = txtenNV.Text;
            string NgaySinh = txngayNV.Text;
            string GT = txgtNV.Text;
            string CV = txcvNV.Text;


            if (AccountDAO.Instance.DeleteAccount(TenDN))
            {
                MessageBox.Show("Xóathành công", "Thông báo");
                loadTK();
            }
            else
            {
                MessageBox.Show("Xóa thất bại, vui lòng kiễm tra lại", "Thông báo");
            }
        }

        private void bttimTK_Click(object sender, EventArgs e)
        {
            AccountList.DataSource=SearchAcc(ttimTK.Text);
        }
    }
}
