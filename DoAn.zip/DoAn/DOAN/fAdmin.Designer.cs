﻿
namespace DOAN
{
    partial class fAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TabC = new System.Windows.Forms.TabControl();
            this.PGP = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.txmaskP = new System.Windows.Forms.TextBox();
            this.txmascP = new System.Windows.Forms.TextBox();
            this.txmtP = new System.Windows.Forms.TextBox();
            this.txtenDN3 = new System.Windows.Forms.TextBox();
            this.txmaQG = new System.Windows.Forms.TextBox();
            this.txnktP = new System.Windows.Forms.TextBox();
            this.txncP = new System.Windows.Forms.TextBox();
            this.txtlP = new System.Windows.Forms.TextBox();
            this.txtenP = new System.Windows.Forms.TextBox();
            this.txmaP = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.DGVP = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.ttimP = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.bttimP = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btloadP = new System.Windows.Forms.Button();
            this.btxoaP = new System.Windows.Forms.Button();
            this.btsuaP = new System.Windows.Forms.Button();
            this.btthemP = new System.Windows.Forms.Button();
            this.PGSK = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txNDR = new System.Windows.Forms.TextBox();
            this.txmaSK = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btloadSK = new System.Windows.Forms.Button();
            this.btxoaSK = new System.Windows.Forms.Button();
            this.btsuaSK = new System.Windows.Forms.Button();
            this.btthemSK = new System.Windows.Forms.Button();
            this.DGVSK = new System.Windows.Forms.DataGridView();
            this.PGTK = new System.Windows.Forms.TabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txmkNV = new System.Windows.Forms.TextBox();
            this.txcvNV = new System.Windows.Forms.TextBox();
            this.txgtNV = new System.Windows.Forms.TextBox();
            this.txngayNV = new System.Windows.Forms.TextBox();
            this.txtenNV = new System.Windows.Forms.TextBox();
            this.txmaNV = new System.Windows.Forms.TextBox();
            this.txtenDN = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.ttimTK = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.bttimTK = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.btloadTK = new System.Windows.Forms.Button();
            this.btxoaTK = new System.Windows.Forms.Button();
            this.btsuaTK = new System.Windows.Forms.Button();
            this.btthemTK = new System.Windows.Forms.Button();
            this.DGVTK = new System.Windows.Forms.DataGridView();
            this.PGTA = new System.Windows.Forms.TabPage();
            this.panel11 = new System.Windows.Forms.Panel();
            this.txtenDN2 = new System.Windows.Forms.TextBox();
            this.txgiaTA = new System.Windows.Forms.TextBox();
            this.txtenTA = new System.Windows.Forms.TextBox();
            this.txmaTA = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.ttimTA = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.bttimTA = new System.Windows.Forms.Button();
            this.panel10 = new System.Windows.Forms.Panel();
            this.btloadTA = new System.Windows.Forms.Button();
            this.btxoaTA = new System.Windows.Forms.Button();
            this.btsuaTA = new System.Windows.Forms.Button();
            this.bthemTA = new System.Windows.Forms.Button();
            this.DGVTA = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cbmalP = new System.Windows.Forms.ComboBox();
            this.TabC.SuspendLayout();
            this.PGP.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVP)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel7.SuspendLayout();
            this.PGSK.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVSK)).BeginInit();
            this.PGTK.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVTK)).BeginInit();
            this.PGTA.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVTA)).BeginInit();
            this.SuspendLayout();
            // 
            // TabC
            // 
            this.TabC.Controls.Add(this.PGP);
            this.TabC.Controls.Add(this.PGSK);
            this.TabC.Controls.Add(this.PGTK);
            this.TabC.Controls.Add(this.PGTA);
            this.TabC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TabC.Location = new System.Drawing.Point(0, 0);
            this.TabC.Name = "TabC";
            this.TabC.SelectedIndex = 0;
            this.TabC.Size = new System.Drawing.Size(821, 507);
            this.TabC.TabIndex = 0;
            // 
            // PGP
            // 
            this.PGP.Controls.Add(this.panel1);
            this.PGP.Controls.Add(this.DGVP);
            this.PGP.Controls.Add(this.panel2);
            this.PGP.Controls.Add(this.panel7);
            this.PGP.Location = new System.Drawing.Point(4, 22);
            this.PGP.Name = "PGP";
            this.PGP.Padding = new System.Windows.Forms.Padding(3);
            this.PGP.Size = new System.Drawing.Size(813, 481);
            this.PGP.TabIndex = 1;
            this.PGP.Text = "Thông tin phim";
            this.PGP.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cbmalP);
            this.panel1.Controls.Add(this.label30);
            this.panel1.Controls.Add(this.label29);
            this.panel1.Controls.Add(this.label28);
            this.panel1.Controls.Add(this.label27);
            this.panel1.Controls.Add(this.label26);
            this.panel1.Controls.Add(this.txmaskP);
            this.panel1.Controls.Add(this.txmascP);
            this.panel1.Controls.Add(this.txmtP);
            this.panel1.Controls.Add(this.txtenDN3);
            this.panel1.Controls.Add(this.txmaQG);
            this.panel1.Controls.Add(this.txnktP);
            this.panel1.Controls.Add(this.txncP);
            this.panel1.Controls.Add(this.txtlP);
            this.panel1.Controls.Add(this.txtenP);
            this.panel1.Controls.Add(this.txmaP);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.label24);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Location = new System.Drawing.Point(514, 64);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(293, 421);
            this.panel1.TabIndex = 8;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(14, 208);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(45, 13);
            this.label30.TabIndex = 22;
            this.label30.Text = "Mã Loại";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(14, 182);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(59, 13);
            this.label29.TabIndex = 21;
            this.label29.Text = "Mô tả phim";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(14, 260);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(99, 13);
            this.label28.TabIndex = 20;
            this.label28.Text = "Tên đăng nhập NV";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(14, 312);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(55, 13);
            this.label27.TabIndex = 19;
            this.label27.Text = "Mã loại sk";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(14, 286);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(74, 13);
            this.label26.TabIndex = 18;
            this.label26.Text = "Mã suất chiếu";
            // 
            // txmaskP
            // 
            this.txmaskP.Location = new System.Drawing.Point(122, 309);
            this.txmaskP.Name = "txmaskP";
            this.txmaskP.Size = new System.Drawing.Size(168, 20);
            this.txmaskP.TabIndex = 17;
            // 
            // txmascP
            // 
            this.txmascP.Location = new System.Drawing.Point(122, 283);
            this.txmascP.Name = "txmascP";
            this.txmascP.Size = new System.Drawing.Size(168, 20);
            this.txmascP.TabIndex = 16;
            // 
            // txmtP
            // 
            this.txmtP.Location = new System.Drawing.Point(122, 179);
            this.txmtP.Name = "txmtP";
            this.txmtP.Size = new System.Drawing.Size(168, 20);
            this.txmtP.TabIndex = 15;
            // 
            // txtenDN3
            // 
            this.txtenDN3.Location = new System.Drawing.Point(122, 257);
            this.txtenDN3.Name = "txtenDN3";
            this.txtenDN3.Size = new System.Drawing.Size(168, 20);
            this.txtenDN3.TabIndex = 14;
            // 
            // txmaQG
            // 
            this.txmaQG.Location = new System.Drawing.Point(122, 231);
            this.txmaQG.Name = "txmaQG";
            this.txmaQG.Size = new System.Drawing.Size(168, 20);
            this.txmaQG.TabIndex = 13;
            // 
            // txnktP
            // 
            this.txnktP.Location = new System.Drawing.Point(122, 153);
            this.txnktP.Name = "txnktP";
            this.txnktP.Size = new System.Drawing.Size(168, 20);
            this.txnktP.TabIndex = 12;
            // 
            // txncP
            // 
            this.txncP.Location = new System.Drawing.Point(122, 127);
            this.txncP.Name = "txncP";
            this.txncP.Size = new System.Drawing.Size(168, 20);
            this.txncP.TabIndex = 11;
            // 
            // txtlP
            // 
            this.txtlP.Location = new System.Drawing.Point(122, 101);
            this.txtlP.Name = "txtlP";
            this.txtlP.Size = new System.Drawing.Size(168, 20);
            this.txtlP.TabIndex = 9;
            // 
            // txtenP
            // 
            this.txtenP.Location = new System.Drawing.Point(122, 75);
            this.txtenP.Name = "txtenP";
            this.txtenP.Size = new System.Drawing.Size(168, 20);
            this.txtenP.TabIndex = 8;
            // 
            // txmaP
            // 
            this.txmaP.Location = new System.Drawing.Point(122, 49);
            this.txmaP.Name = "txmaP";
            this.txmaP.Size = new System.Drawing.Size(168, 20);
            this.txmaP.TabIndex = 7;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(14, 234);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(68, 13);
            this.label13.TabIndex = 6;
            this.label13.Text = "Mã Quốc gia";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(14, 156);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(49, 13);
            this.label14.TabIndex = 6;
            this.label14.Text = "Ngày KT";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(14, 130);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(62, 13);
            this.label15.TabIndex = 5;
            this.label15.Text = "Ngày Chiếu";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(14, 104);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(57, 13);
            this.label22.TabIndex = 3;
            this.label22.Text = "Thời lượng";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(14, 78);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(52, 13);
            this.label23.TabIndex = 2;
            this.label23.Text = "Tên Phim";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(14, 52);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(48, 13);
            this.label24.TabIndex = 1;
            this.label24.Text = "Mã Phim";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(119, 26);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(77, 13);
            this.label25.TabIndex = 0;
            this.label25.Text = "Thông tin phim";
            // 
            // DGVP
            // 
            this.DGVP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVP.Location = new System.Drawing.Point(3, 64);
            this.DGVP.Name = "DGVP";
            this.DGVP.Size = new System.Drawing.Size(505, 414);
            this.DGVP.TabIndex = 5;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.ttimP);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.bttimP);
            this.panel2.Location = new System.Drawing.Point(315, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(490, 52);
            this.panel2.TabIndex = 4;
            // 
            // ttimP
            // 
            this.ttimP.Location = new System.Drawing.Point(83, 18);
            this.ttimP.Name = "ttimP";
            this.ttimP.Size = new System.Drawing.Size(285, 20);
            this.ttimP.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "ID Phim";
            // 
            // bttimP
            // 
            this.bttimP.Location = new System.Drawing.Point(385, 3);
            this.bttimP.Name = "bttimP";
            this.bttimP.Size = new System.Drawing.Size(58, 49);
            this.bttimP.TabIndex = 4;
            this.bttimP.Text = "Tìm Kiếm";
            this.bttimP.UseVisualStyleBackColor = true;
            this.bttimP.Click += new System.EventHandler(this.bttimP_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.btloadP);
            this.panel7.Controls.Add(this.btxoaP);
            this.panel7.Controls.Add(this.btsuaP);
            this.panel7.Controls.Add(this.btthemP);
            this.panel7.Location = new System.Drawing.Point(8, 6);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(301, 52);
            this.panel7.TabIndex = 3;
            // 
            // btloadP
            // 
            this.btloadP.Location = new System.Drawing.Point(229, 3);
            this.btloadP.Name = "btloadP";
            this.btloadP.Size = new System.Drawing.Size(58, 41);
            this.btloadP.TabIndex = 3;
            this.btloadP.Text = "Load";
            this.btloadP.UseVisualStyleBackColor = true;
            this.btloadP.Click += new System.EventHandler(this.btloadP_Click);
            // 
            // btxoaP
            // 
            this.btxoaP.Location = new System.Drawing.Point(155, 3);
            this.btxoaP.Name = "btxoaP";
            this.btxoaP.Size = new System.Drawing.Size(58, 41);
            this.btxoaP.TabIndex = 2;
            this.btxoaP.Text = "Xóa";
            this.btxoaP.UseVisualStyleBackColor = true;
            this.btxoaP.Click += new System.EventHandler(this.btxoaP_Click);
            // 
            // btsuaP
            // 
            this.btsuaP.Location = new System.Drawing.Point(78, 3);
            this.btsuaP.Name = "btsuaP";
            this.btsuaP.Size = new System.Drawing.Size(58, 41);
            this.btsuaP.TabIndex = 1;
            this.btsuaP.Text = "Sửa";
            this.btsuaP.UseVisualStyleBackColor = true;
            this.btsuaP.Click += new System.EventHandler(this.btsuaP_Click);
            // 
            // btthemP
            // 
            this.btthemP.Location = new System.Drawing.Point(3, 3);
            this.btthemP.Name = "btthemP";
            this.btthemP.Size = new System.Drawing.Size(58, 41);
            this.btthemP.TabIndex = 0;
            this.btthemP.Text = "Thêm";
            this.btthemP.UseVisualStyleBackColor = true;
            this.btthemP.Click += new System.EventHandler(this.btthemP_Click);
            // 
            // PGSK
            // 
            this.PGSK.Controls.Add(this.panel3);
            this.PGSK.Controls.Add(this.panel8);
            this.PGSK.Controls.Add(this.DGVSK);
            this.PGSK.Location = new System.Drawing.Point(4, 22);
            this.PGSK.Name = "PGSK";
            this.PGSK.Padding = new System.Windows.Forms.Padding(3);
            this.PGSK.Size = new System.Drawing.Size(813, 481);
            this.PGSK.TabIndex = 2;
            this.PGSK.Text = "Thông tin sự kiện";
            this.PGSK.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.txNDR);
            this.panel3.Controls.Add(this.txmaSK);
            this.panel3.Controls.Add(this.label31);
            this.panel3.Controls.Add(this.label32);
            this.panel3.Controls.Add(this.label33);
            this.panel3.Location = new System.Drawing.Point(514, 64);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(293, 421);
            this.panel3.TabIndex = 9;
            // 
            // txNDR
            // 
            this.txNDR.Location = new System.Drawing.Point(122, 111);
            this.txNDR.Name = "txNDR";
            this.txNDR.Size = new System.Drawing.Size(168, 20);
            this.txNDR.TabIndex = 8;
            // 
            // txmaSK
            // 
            this.txmaSK.Location = new System.Drawing.Point(122, 67);
            this.txmaSK.Name = "txmaSK";
            this.txmaSK.Size = new System.Drawing.Size(168, 20);
            this.txmaSK.TabIndex = 7;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(14, 111);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(74, 13);
            this.label31.TabIndex = 2;
            this.label31.Text = "Ngay Dien Ra";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(14, 70);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(62, 13);
            this.label32.TabIndex = 1;
            this.label32.Text = "Ma Loai SK";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(100, 25);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(91, 13);
            this.label33.TabIndex = 0;
            this.label33.Text = "Thông tin thức ăn";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.btloadSK);
            this.panel8.Controls.Add(this.btxoaSK);
            this.panel8.Controls.Add(this.btsuaSK);
            this.panel8.Controls.Add(this.btthemSK);
            this.panel8.Location = new System.Drawing.Point(8, 6);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(500, 52);
            this.panel8.TabIndex = 3;
            // 
            // btloadSK
            // 
            this.btloadSK.Location = new System.Drawing.Point(229, 3);
            this.btloadSK.Name = "btloadSK";
            this.btloadSK.Size = new System.Drawing.Size(58, 41);
            this.btloadSK.TabIndex = 3;
            this.btloadSK.Text = "Load";
            this.btloadSK.UseVisualStyleBackColor = true;
            this.btloadSK.Click += new System.EventHandler(this.btloadSK_Click);
            // 
            // btxoaSK
            // 
            this.btxoaSK.Location = new System.Drawing.Point(155, 3);
            this.btxoaSK.Name = "btxoaSK";
            this.btxoaSK.Size = new System.Drawing.Size(58, 41);
            this.btxoaSK.TabIndex = 2;
            this.btxoaSK.Text = "Xóa";
            this.btxoaSK.UseVisualStyleBackColor = true;
            this.btxoaSK.Click += new System.EventHandler(this.btxoaSK_Click);
            // 
            // btsuaSK
            // 
            this.btsuaSK.Location = new System.Drawing.Point(78, 3);
            this.btsuaSK.Name = "btsuaSK";
            this.btsuaSK.Size = new System.Drawing.Size(58, 41);
            this.btsuaSK.TabIndex = 1;
            this.btsuaSK.Text = "Sửa";
            this.btsuaSK.UseVisualStyleBackColor = true;
            this.btsuaSK.Click += new System.EventHandler(this.btsuaSK_Click);
            // 
            // btthemSK
            // 
            this.btthemSK.Location = new System.Drawing.Point(3, 3);
            this.btthemSK.Name = "btthemSK";
            this.btthemSK.Size = new System.Drawing.Size(58, 41);
            this.btthemSK.TabIndex = 0;
            this.btthemSK.Text = "Thêm";
            this.btthemSK.UseVisualStyleBackColor = true;
            this.btthemSK.Click += new System.EventHandler(this.btthemSK_Click);
            // 
            // DGVSK
            // 
            this.DGVSK.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVSK.Location = new System.Drawing.Point(3, 64);
            this.DGVSK.Name = "DGVSK";
            this.DGVSK.Size = new System.Drawing.Size(505, 414);
            this.DGVSK.TabIndex = 0;
            // 
            // PGTK
            // 
            this.PGTK.Controls.Add(this.panel6);
            this.PGTK.Controls.Add(this.panel4);
            this.PGTK.Controls.Add(this.panel9);
            this.PGTK.Controls.Add(this.DGVTK);
            this.PGTK.Location = new System.Drawing.Point(4, 22);
            this.PGTK.Name = "PGTK";
            this.PGTK.Padding = new System.Windows.Forms.Padding(3);
            this.PGTK.Size = new System.Drawing.Size(813, 481);
            this.PGTK.TabIndex = 3;
            this.PGTK.Text = "Thông tin tài khoản";
            this.PGTK.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.txmkNV);
            this.panel6.Controls.Add(this.txcvNV);
            this.panel6.Controls.Add(this.txgtNV);
            this.panel6.Controls.Add(this.txngayNV);
            this.panel6.Controls.Add(this.txtenNV);
            this.panel6.Controls.Add(this.txmaNV);
            this.panel6.Controls.Add(this.txtenDN);
            this.panel6.Controls.Add(this.label12);
            this.panel6.Controls.Add(this.label11);
            this.panel6.Controls.Add(this.label10);
            this.panel6.Controls.Add(this.label9);
            this.panel6.Controls.Add(this.label8);
            this.panel6.Controls.Add(this.label7);
            this.panel6.Controls.Add(this.label6);
            this.panel6.Controls.Add(this.label5);
            this.panel6.Location = new System.Drawing.Point(514, 64);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(293, 421);
            this.panel6.TabIndex = 7;
            // 
            // txmkNV
            // 
            this.txmkNV.Location = new System.Drawing.Point(122, 304);
            this.txmkNV.Name = "txmkNV";
            this.txmkNV.Size = new System.Drawing.Size(168, 20);
            this.txmkNV.TabIndex = 12;
            // 
            // txcvNV
            // 
            this.txcvNV.Location = new System.Drawing.Point(122, 268);
            this.txcvNV.Name = "txcvNV";
            this.txcvNV.Size = new System.Drawing.Size(168, 20);
            this.txcvNV.TabIndex = 12;
            // 
            // txgtNV
            // 
            this.txgtNV.Location = new System.Drawing.Point(122, 231);
            this.txgtNV.Name = "txgtNV";
            this.txgtNV.Size = new System.Drawing.Size(168, 20);
            this.txgtNV.TabIndex = 11;
            // 
            // txngayNV
            // 
            this.txngayNV.Location = new System.Drawing.Point(122, 193);
            this.txngayNV.Name = "txngayNV";
            this.txngayNV.Size = new System.Drawing.Size(168, 20);
            this.txngayNV.TabIndex = 10;
            // 
            // txtenNV
            // 
            this.txtenNV.Location = new System.Drawing.Point(122, 153);
            this.txtenNV.Name = "txtenNV";
            this.txtenNV.Size = new System.Drawing.Size(168, 20);
            this.txtenNV.TabIndex = 9;
            // 
            // txmaNV
            // 
            this.txmaNV.Location = new System.Drawing.Point(122, 111);
            this.txmaNV.Name = "txmaNV";
            this.txmaNV.Size = new System.Drawing.Size(168, 20);
            this.txmaNV.TabIndex = 8;
            // 
            // txtenDN
            // 
            this.txtenDN.Location = new System.Drawing.Point(122, 67);
            this.txtenDN.Name = "txtenDN";
            this.txtenDN.Size = new System.Drawing.Size(168, 20);
            this.txtenDN.TabIndex = 7;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(14, 307);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 13);
            this.label12.TabIndex = 6;
            this.label12.Text = "Mật Khẩu";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(14, 271);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(47, 13);
            this.label11.TabIndex = 6;
            this.label11.Text = "Chức vụ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(14, 234);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(51, 13);
            this.label10.TabIndex = 5;
            this.label10.Text = "Giới Tính";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 193);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 13);
            this.label9.TabIndex = 4;
            this.label9.Text = "Ngày Sinh";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(14, 153);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "Ten NV";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 111);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 13);
            this.label7.TabIndex = 2;
            this.label7.Text = "Mã NV";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 70);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Tên đăng nhập";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(100, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Thông tin tài khoản ";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.ttimTK);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.bttimTK);
            this.panel4.Location = new System.Drawing.Point(315, 6);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(490, 52);
            this.panel4.TabIndex = 4;
            // 
            // ttimTK
            // 
            this.ttimTK.Location = new System.Drawing.Point(83, 18);
            this.ttimTK.Name = "ttimTK";
            this.ttimTK.Size = new System.Drawing.Size(285, 20);
            this.ttimTK.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "ID Tài Khoản";
            // 
            // bttimTK
            // 
            this.bttimTK.Location = new System.Drawing.Point(385, 3);
            this.bttimTK.Name = "bttimTK";
            this.bttimTK.Size = new System.Drawing.Size(58, 49);
            this.bttimTK.TabIndex = 4;
            this.bttimTK.Text = "Tìm Kiếm";
            this.bttimTK.UseVisualStyleBackColor = true;
            this.bttimTK.Click += new System.EventHandler(this.bttimTK_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.btloadTK);
            this.panel9.Controls.Add(this.btxoaTK);
            this.panel9.Controls.Add(this.btsuaTK);
            this.panel9.Controls.Add(this.btthemTK);
            this.panel9.Location = new System.Drawing.Point(8, 6);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(301, 52);
            this.panel9.TabIndex = 3;
            // 
            // btloadTK
            // 
            this.btloadTK.Location = new System.Drawing.Point(229, 3);
            this.btloadTK.Name = "btloadTK";
            this.btloadTK.Size = new System.Drawing.Size(58, 41);
            this.btloadTK.TabIndex = 3;
            this.btloadTK.Text = "Load";
            this.btloadTK.UseVisualStyleBackColor = true;
            this.btloadTK.Click += new System.EventHandler(this.btloadTK_Click);
            // 
            // btxoaTK
            // 
            this.btxoaTK.Location = new System.Drawing.Point(155, 3);
            this.btxoaTK.Name = "btxoaTK";
            this.btxoaTK.Size = new System.Drawing.Size(58, 41);
            this.btxoaTK.TabIndex = 2;
            this.btxoaTK.Text = "Xóa";
            this.btxoaTK.UseVisualStyleBackColor = true;
            this.btxoaTK.Click += new System.EventHandler(this.btxoaTK_Click);
            // 
            // btsuaTK
            // 
            this.btsuaTK.Location = new System.Drawing.Point(78, 3);
            this.btsuaTK.Name = "btsuaTK";
            this.btsuaTK.Size = new System.Drawing.Size(58, 41);
            this.btsuaTK.TabIndex = 1;
            this.btsuaTK.Text = "Sửa";
            this.btsuaTK.UseVisualStyleBackColor = true;
            this.btsuaTK.Click += new System.EventHandler(this.btsuaTK_Click_1);
            // 
            // btthemTK
            // 
            this.btthemTK.Location = new System.Drawing.Point(3, 3);
            this.btthemTK.Name = "btthemTK";
            this.btthemTK.Size = new System.Drawing.Size(58, 41);
            this.btthemTK.TabIndex = 0;
            this.btthemTK.Text = "Thêm";
            this.btthemTK.UseVisualStyleBackColor = true;
            this.btthemTK.Click += new System.EventHandler(this.btthemTK_Click);
            // 
            // DGVTK
            // 
            this.DGVTK.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVTK.Location = new System.Drawing.Point(3, 64);
            this.DGVTK.Name = "DGVTK";
            this.DGVTK.Size = new System.Drawing.Size(505, 414);
            this.DGVTK.TabIndex = 0;
            // 
            // PGTA
            // 
            this.PGTA.Controls.Add(this.panel11);
            this.PGTA.Controls.Add(this.panel5);
            this.PGTA.Controls.Add(this.panel10);
            this.PGTA.Controls.Add(this.DGVTA);
            this.PGTA.Location = new System.Drawing.Point(4, 22);
            this.PGTA.Name = "PGTA";
            this.PGTA.Padding = new System.Windows.Forms.Padding(3);
            this.PGTA.Size = new System.Drawing.Size(813, 481);
            this.PGTA.TabIndex = 4;
            this.PGTA.Text = "Thông tin món ăn";
            this.PGTA.UseVisualStyleBackColor = true;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.txtenDN2);
            this.panel11.Controls.Add(this.txgiaTA);
            this.panel11.Controls.Add(this.txtenTA);
            this.panel11.Controls.Add(this.txmaTA);
            this.panel11.Controls.Add(this.label16);
            this.panel11.Controls.Add(this.label17);
            this.panel11.Controls.Add(this.label18);
            this.panel11.Controls.Add(this.label19);
            this.panel11.Controls.Add(this.label20);
            this.panel11.Location = new System.Drawing.Point(512, 64);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(293, 421);
            this.panel11.TabIndex = 8;
            // 
            // txtenDN2
            // 
            this.txtenDN2.Location = new System.Drawing.Point(122, 193);
            this.txtenDN2.Name = "txtenDN2";
            this.txtenDN2.Size = new System.Drawing.Size(168, 20);
            this.txtenDN2.TabIndex = 10;
            // 
            // txgiaTA
            // 
            this.txgiaTA.Location = new System.Drawing.Point(122, 153);
            this.txgiaTA.Name = "txgiaTA";
            this.txgiaTA.Size = new System.Drawing.Size(168, 20);
            this.txgiaTA.TabIndex = 9;
            // 
            // txtenTA
            // 
            this.txtenTA.Location = new System.Drawing.Point(122, 111);
            this.txtenTA.Name = "txtenTA";
            this.txtenTA.Size = new System.Drawing.Size(168, 20);
            this.txtenTA.TabIndex = 8;
            // 
            // txmaTA
            // 
            this.txmaTA.Location = new System.Drawing.Point(122, 67);
            this.txmaTA.Name = "txmaTA";
            this.txmaTA.Size = new System.Drawing.Size(168, 20);
            this.txmaTA.TabIndex = 7;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(14, 196);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(99, 13);
            this.label16.TabIndex = 4;
            this.label16.Text = "Tên đăng nhập NV";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(14, 153);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(23, 13);
            this.label17.TabIndex = 3;
            this.label17.Text = "Giá";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(14, 111);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(69, 13);
            this.label18.TabIndex = 2;
            this.label18.Text = "Tên Thức ăn";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(14, 70);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(61, 13);
            this.label19.TabIndex = 1;
            this.label19.Text = "Mã thức ăn";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(100, 25);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(91, 13);
            this.label20.TabIndex = 0;
            this.label20.Text = "Thông tin thức ăn";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.ttimTA);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Controls.Add(this.bttimTA);
            this.panel5.Location = new System.Drawing.Point(315, 6);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(490, 52);
            this.panel5.TabIndex = 4;
            // 
            // ttimTA
            // 
            this.ttimTA.Location = new System.Drawing.Point(83, 18);
            this.ttimTA.Name = "ttimTA";
            this.ttimTA.Size = new System.Drawing.Size(285, 20);
            this.ttimTA.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "ID Thức ăn";
            // 
            // bttimTA
            // 
            this.bttimTA.Location = new System.Drawing.Point(385, 3);
            this.bttimTA.Name = "bttimTA";
            this.bttimTA.Size = new System.Drawing.Size(58, 49);
            this.bttimTA.TabIndex = 4;
            this.bttimTA.Text = "Tìm Kiếm";
            this.bttimTA.UseVisualStyleBackColor = true;
            this.bttimTA.Click += new System.EventHandler(this.bttimTA_Click);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.btloadTA);
            this.panel10.Controls.Add(this.btxoaTA);
            this.panel10.Controls.Add(this.btsuaTA);
            this.panel10.Controls.Add(this.bthemTA);
            this.panel10.Location = new System.Drawing.Point(8, 6);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(301, 52);
            this.panel10.TabIndex = 3;
            // 
            // btloadTA
            // 
            this.btloadTA.Location = new System.Drawing.Point(229, 3);
            this.btloadTA.Name = "btloadTA";
            this.btloadTA.Size = new System.Drawing.Size(58, 41);
            this.btloadTA.TabIndex = 3;
            this.btloadTA.Text = "Load";
            this.btloadTA.UseVisualStyleBackColor = true;
            this.btloadTA.Click += new System.EventHandler(this.btloadTA_Click);
            // 
            // btxoaTA
            // 
            this.btxoaTA.Location = new System.Drawing.Point(155, 3);
            this.btxoaTA.Name = "btxoaTA";
            this.btxoaTA.Size = new System.Drawing.Size(58, 41);
            this.btxoaTA.TabIndex = 2;
            this.btxoaTA.Text = "Xóa";
            this.btxoaTA.UseVisualStyleBackColor = true;
            this.btxoaTA.Click += new System.EventHandler(this.btxoaTA_Click);
            // 
            // btsuaTA
            // 
            this.btsuaTA.Location = new System.Drawing.Point(78, 3);
            this.btsuaTA.Name = "btsuaTA";
            this.btsuaTA.Size = new System.Drawing.Size(58, 41);
            this.btsuaTA.TabIndex = 1;
            this.btsuaTA.Text = "Sửa";
            this.btsuaTA.UseVisualStyleBackColor = true;
            this.btsuaTA.Click += new System.EventHandler(this.btsuaTA_Click);
            // 
            // bthemTA
            // 
            this.bthemTA.Location = new System.Drawing.Point(3, 3);
            this.bthemTA.Name = "bthemTA";
            this.bthemTA.Size = new System.Drawing.Size(58, 41);
            this.bthemTA.TabIndex = 0;
            this.bthemTA.Text = "Thêm";
            this.bthemTA.UseVisualStyleBackColor = true;
            this.bthemTA.Click += new System.EventHandler(this.bthemTA_Click);
            // 
            // DGVTA
            // 
            this.DGVTA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVTA.Location = new System.Drawing.Point(3, 63);
            this.DGVTA.Name = "DGVTA";
            this.DGVTA.Size = new System.Drawing.Size(503, 415);
            this.DGVTA.TabIndex = 0;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // cbmalP
            // 
            this.cbmalP.FormattingEnabled = true;
            this.cbmalP.Location = new System.Drawing.Point(123, 205);
            this.cbmalP.Name = "cbmalP";
            this.cbmalP.Size = new System.Drawing.Size(167, 21);
            this.cbmalP.TabIndex = 23;
            // 
            // fAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(821, 507);
            this.Controls.Add(this.TabC);
            this.Name = "fAdmin";
            this.Text = "Admin";
            this.TabC.ResumeLayout(false);
            this.PGP.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVP)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.PGSK.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGVSK)).EndInit();
            this.PGTK.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGVTK)).EndInit();
            this.PGTA.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGVTA)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl TabC;
        private System.Windows.Forms.TabPage PGP;
        private System.Windows.Forms.TabPage PGSK;
        private System.Windows.Forms.DataGridView DGVSK;
        private System.Windows.Forms.TabPage PGTK;
        private System.Windows.Forms.DataGridView DGVTK;
        private System.Windows.Forms.TabPage PGTA;
        private System.Windows.Forms.DataGridView DGVTA;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox ttimP;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bttimP;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button btloadP;
        private System.Windows.Forms.Button btxoaP;
        private System.Windows.Forms.Button btsuaP;
        private System.Windows.Forms.Button btthemP;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button btloadSK;
        private System.Windows.Forms.Button btxoaSK;
        private System.Windows.Forms.Button btsuaSK;
        private System.Windows.Forms.Button btthemSK;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox ttimTK;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button bttimTK;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button btloadTK;
        private System.Windows.Forms.Button btxoaTK;
        private System.Windows.Forms.Button btsuaTK;
        private System.Windows.Forms.Button btthemTK;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox ttimTA;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button bttimTA;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button btloadTA;
        private System.Windows.Forms.Button btxoaTA;
        private System.Windows.Forms.Button btsuaTA;
        private System.Windows.Forms.Button bthemTA;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.DataGridView DGVP;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox txcvNV;
        private System.Windows.Forms.TextBox txgtNV;
        private System.Windows.Forms.TextBox txngayNV;
        private System.Windows.Forms.TextBox txtenNV;
        private System.Windows.Forms.TextBox txmaNV;
        private System.Windows.Forms.TextBox txtenDN;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txmkNV;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox txgiaTA;
        private System.Windows.Forms.TextBox txtenTA;
        private System.Windows.Forms.TextBox txmaTA;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtenDN2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txmaskP;
        private System.Windows.Forms.TextBox txmascP;
        private System.Windows.Forms.TextBox txmtP;
        private System.Windows.Forms.TextBox txtenDN3;
        private System.Windows.Forms.TextBox txmaQG;
        private System.Windows.Forms.TextBox txnktP;
        private System.Windows.Forms.TextBox txncP;
        private System.Windows.Forms.TextBox txtlP;
        private System.Windows.Forms.TextBox txtenP;
        private System.Windows.Forms.TextBox txmaP;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txNDR;
        private System.Windows.Forms.TextBox txmaSK;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.ComboBox cbmalP;
    }
}

