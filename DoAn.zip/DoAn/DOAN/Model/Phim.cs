namespace DOAN.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Phim")]
    public partial class Phim
    {
        [Key]
        [StringLength(10)]
        public string MaPhim { get; set; }

        [Required]
        [StringLength(50)]
        public string TenPhim { get; set; }

        [Required]
        [StringLength(30)]
        public string Thoiluong { get; set; }

        [StringLength(20)]
        public string NgayChieu { get; set; }

        [StringLength(20)]
        public string NgayKT { get; set; }

        [StringLength(50)]
        public string MoTaPhim { get; set; }

        [Required]
        [StringLength(10)]
        public string MaLoai { get; set; }

        [Required]
        [StringLength(10)]
        public string MaQuocGia { get; set; }

        [Required]
        [StringLength(30)]
        public string TenDangNhapNV { get; set; }

        [Required]
        [StringLength(10)]
        public string MASC { get; set; }

        [Required]
        [StringLength(10)]
        public string Maloaisukien { get; set; }

        public virtual LOAIPHIM LOAIPHIM { get; set; }
    }
}
