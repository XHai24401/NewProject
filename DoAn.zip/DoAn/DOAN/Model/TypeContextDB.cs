using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace DOAN.Model
{
    public partial class TypeContextDB : DbContext
    {
        public TypeContextDB()
            : base("name=TypeContextDB")
        {
        }

        public virtual DbSet<LOAIPHIM> LOAIPHIMs { get; set; }
        public virtual DbSet<Phim> Phims { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<LOAIPHIM>()
                .Property(e => e.MaLoai)
                .IsUnicode(false);

            modelBuilder.Entity<LOAIPHIM>()
                .HasMany(e => e.Phims)
                .WithRequired(e => e.LOAIPHIM)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Phim>()
                .Property(e => e.MaPhim)
                .IsUnicode(false);

            modelBuilder.Entity<Phim>()
                .Property(e => e.NgayChieu)
                .IsUnicode(false);

            modelBuilder.Entity<Phim>()
                .Property(e => e.NgayKT)
                .IsUnicode(false);

            modelBuilder.Entity<Phim>()
                .Property(e => e.MaLoai)
                .IsUnicode(false);

            modelBuilder.Entity<Phim>()
                .Property(e => e.MaQuocGia)
                .IsUnicode(false);

            modelBuilder.Entity<Phim>()
                .Property(e => e.TenDangNhapNV)
                .IsUnicode(false);

            modelBuilder.Entity<Phim>()
                .Property(e => e.MASC)
                .IsUnicode(false);

            modelBuilder.Entity<Phim>()
                .Property(e => e.Maloaisukien)
                .IsUnicode(false);
        }
    }
}
